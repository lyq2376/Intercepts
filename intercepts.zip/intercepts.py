"""
    file: intercepts.py
    description: Test 10 calls to test_case() to see what functions have x and y intercepts
    language: python 3
    author: Lindy Quach
    section: 3 (Group A)
"""


def no_x_intercept(m, b):
    """
        precondition: Checking to see if there are any x intercepts
        postcondition: Return True if no x intercept exists
        postcondition: Return False if otherwise
    """

    if m == 0 and b != 0:
        return True
    else:
        return False


def x_intercept(m, b):
    """
        precondition: There is a x-intercept in a function
        postcondition: Found the x-intercept in the function
    """
    if m == 0:
        return None
    elif b > 0:
        x = (0 - b) / m
        return x
    else:
        x = (0 + b) / m
        return x


def y_intercept(m, b):
    """
        precondition: There is a y-intercept in a function
        postcondition: Found the y-intercept in the function
    """
    if b == 0:
        return 0
    elif b > 0:
        y = (m * 0) + b
        return y
    else:
        y = (m * 0) - b
        return y


def print_point(x, y):
    """
        precondition: Has x and y intercepts
        postcondition: Has the x and y intercepts in (x, y) format
    """
    if x is None:
        print('(NONE)', end=' ')
    else:
        print(f'({x:.3f}, {y:.3f})', end=' ')


def test_case(m, b):
    """
        precondition: Has both x and y intercepts in (x, y) format
        postcondition: Print 4 equations of test cases as one call
    """
    xint = x_intercept(m, b)
    yint = y_intercept(m, b)
    print(f'Equation: Y = {m} X + {b}.    Intercepts: ', end='')
    print_point(xint, 0)
    print_point(0, yint)
    print()


def main():
    """
        precondition: Have 40 functions to test
        postcondition: Tested all 40 functions
    """
    test_case(6, 3)
    test_case(0, 5)
    test_case(6, 0)
    test_case(-7, 8)
    test_case(1, -9)
    test_case(0, -3)
    test_case(-4, 0)
    test_case(0, 0)
    test_case(-4, -9)
    test_case(-8, 3)


if __name__ == '__main__':
    main()
